module.exports = {reactStrictMode:true};
